#!/bin/bash

# ===========================================================
#  backup_full.sh - Script de backup con fecha en formato ANSI
#  Ubicación: /opt/scripts/backup_full.sh
#  Uso: ./backup_full.sh -o <origen> -d <destino>
#       ./backup_full.sh -help
# ===========================================================

# -------------------------------------------------------
# Función de ayuda
# -------------------------------------------------------
mostrar_ayuda () {
    echo ""
    echo "========================================================="
    echo "   SCRIPT DE BACKUP - Universidad de Palermo"
    echo "========================================================="
    echo ""
    echo "DESCRIPCIÓN:"
    echo "  Genera un backup comprimido (.tar.gz) del directorio"
    echo "  origen en el directorio destino, con la fecha actual"
    echo "  en formato AAAAMMDD incluida en el nombre del archivo."
    echo ""
    echo "USO:"
    echo "  ./backup_full.sh -o <directorio_origen> -d <directorio_destino>"
    echo "  ./backup_full.sh -help"
    echo ""
    echo "ARGUMENTOS:"
    echo "  -o    Directorio a backupear (origen)"
    echo "  -d    Directorio donde se guarda el backup (destino)"
    echo "  -help Muestra esta ayuda"
    echo ""
    echo "EJEMPLOS:"
    echo "  ./backup_full.sh -o /var/log -d /backup_dir"
    echo "  ./backup_full.sh -o /www_dir  -d /backup_dir"
    echo ""
    echo "NOMBRE DEL ARCHIVO GENERADO:"
    echo "  <nombre_directorio>_bkp_<AAAAMMDD>.tar.gz"
    echo "  Ej: log_bkp_20240302.tar.gz"
    echo ""
    echo "TAREAS PROGRAMADAS (cron):"
    echo "  Todos los días 00:00 hs  → backup de /var/log"
    echo "  Lun/Mié/Vie  23:00 hs   → backup de /www_dir"
    echo "========================================================="
    echo ""
}

# -------------------------------------------------------
# Si se pasa -help, mostrar ayuda y salir
# -------------------------------------------------------
if [[ "$1" == "-help" ]]; then
    mostrar_ayuda
    exit 0
fi

# -------------------------------------------------------
# Parseo de argumentos -o (origen) y -d (destino)
# -------------------------------------------------------
ORIGEN=""
DESTINO=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        -o)
            ORIGEN="$2"
            shift 2
            ;;
        -d)
            DESTINO="$2"
            shift 2
            ;;
        *)
            echo "[ERROR] Argumento desconocido: $1"
            echo "Ejecute './backup.sh -help' para ver el uso correcto."
            exit 1
            ;;
    esac
done

# -------------------------------------------------------
# Validar que se hayan pasado ambos argumentos
# -------------------------------------------------------
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "[ERROR] Debe especificar origen (-o) y destino (-d)."
    echo "Ejecute './backup.sh -help' para ver el uso correcto."
    exit 1
fi

# -------------------------------------------------------
# Validar que el sistema de archivos ORIGEN esté disponible
# (debe ser un directorio existente y con permisos de lectura)
# -------------------------------------------------------
if [[ ! -d "$ORIGEN" ]]; then
    echo "[ERROR] El directorio de origen no existe o no es accesible: $ORIGEN"
    exit 1
fi

if [[ ! -r "$ORIGEN" ]]; then
    echo "[ERROR] Sin permisos de lectura sobre el origen: $ORIGEN"
    exit 1
fi

# -------------------------------------------------------
# Validar que el sistema de archivos DESTINO esté disponible
# (debe ser un directorio existente y con permisos de escritura)
# -------------------------------------------------------
if [[ ! -d "$DESTINO" ]]; then
    echo "[ERROR] El directorio de destino no existe o no está montado: $DESTINO"
    echo "Verifique que la partición de destino esté montada correctamente."
    exit 1
fi

if [[ ! -w "$DESTINO" ]]; then
    echo "[ERROR] Sin permisos de escritura sobre el destino: $DESTINO"
    exit 1
fi

# -------------------------------------------------------
# Verificar que el destino sea un punto de montaje activo
# (el directorio /backup_dir debe estar montado)
# -------------------------------------------------------
if ! mountpoint -q "$DESTINO" 2>/dev/null; then
    echo "[ADVERTENCIA] '$DESTINO' no parece ser un punto de montaje activo."
    echo "Continuando de todas formas, pero verifique que la partición esté montada."
fi

# -------------------------------------------------------
# Construir nombre del archivo de backup
# Formato: <nombre_dir>_bkp_AAAAMMDD.tar.gz
# Ejemplo: log_bkp_20240302.tar.gz
# -------------------------------------------------------
FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")
NOMBRE_ARCHIVO="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"
RUTA_DESTINO="${DESTINO}/${NOMBRE_ARCHIVO}"

# -------------------------------------------------------
# Ejecutar el backup
# -------------------------------------------------------
echo ""
echo "========================================================="
echo "  Iniciando backup..."
echo "  Origen  : $ORIGEN"
echo "  Destino : $RUTA_DESTINO"
echo "  Fecha   : $FECHA"
echo "========================================================="

tar -czf "$RUTA_DESTINO" "$ORIGEN" 2>/dev/null

# -------------------------------------------------------
# Verificar resultado del comando tar ($? = return code)
# -------------------------------------------------------
if [[ $? -eq 0 ]]; then
    echo "[OK] Backup completado exitosamente: $RUTA_DESTINO"
else
    echo "[ERROR] El backup falló. Verifique permisos y espacio disponible."
    exit 1
fi

echo "========================================================="
echo ""
exit 0
