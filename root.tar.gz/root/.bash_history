history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ls
ls -la
cd .config/
ls -la
cd ..
ls -la
cd /
ls
ls -la
cd /etc/apt
ls -la
nano sources.list
vi sources.list
vi sources.list
cd ..
ls
sudo apt-cache update
apt-cache update
apt-cache upgrade
sudo apt update
sudo apt upgrade
lsb_release -a
nano
apt-get install openssh-server
apt-get install nano
nano
cd ..
ls -la
cd etc
ls -la
ls ssh/
nano ssh/sshd_config
ls -la
cd ssh
ñs
ls -la
nano ssh/sshd_config
nano sshd_config
cd ..
ls
man ssh-keygen
ssh-keygen
ls -l
cd ssh
ls -la
cd ..
ls
cd ..
ls
cd root
ls
ls -la
cd .ssh
ls -la
cat id_rsa.pub >> /root/.ssh/authorized_keys
ls
nano authorized_keys 
sudo poweroff
ls
ls -la
cd .ssh/
ls -la
nano authorized_keys 
ls -la
cd ..
ls -la
cd ..
ls -la
cd etc
ls -la
ls
cd ssh/
ls -la
nano sshd_config
ls -la
cd ..
ls -la
cd network/
ls
nano interfaces
reboot
poweroff
ls -la
exit
exit
ls -la
exit
ls
cd root
cd .ssh/
nano authorized_keys 
cd ~
ls
ls -la
sudo apt install apache2 php libapache2-mod-php
ls
cd /etc
ls -la
cd apache2/
ls -la
nano sites-available/
nano apache2.conf 
exit
ls
ls -la
cd /root
ls -la
ls -la
ls
ls -l
ls -a
ls -la .ssh/
cd .ssh/
mv index.php /root/
ls -la .ssh/
ls -la
mv logo.png /root/
cd ..
ls -la
cd /etc
ls
cd apache2/
ls
nano apache2.conf 
nano apache2.conf 
systemctl status apache2
systemctl status apache2
ls
cd ..
ls
cd ..
ls
cd /var
cd ..
cd var
ls
cd www/
ls
nano html
ls -la
cd html
ls
ls -la
nano index.html 
nano index.html 
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
ls
rm index.html 
ls
exit
ls
ls -la
cd .ssh/
ls -la
cd ../..
ls
cd root
cd .ssh/
ls -la
ls -la
nano clave_publica.pub 
ls
nano auth
ls
nano authorized_keys 
ls -la
cat clave_publica.pub » authorized_keys 
ls -la
cat clave_publica.pub » authorized_keys
cat clave_publica.pub »» authorized_keys
cat clave_publica.pub >> authorized_keys 
nano authorized_keys 
nano authorized_keys 
poweroff
ls
ls -la
poweroff
lsblk
fdisk /dev/sdc
lsblk
mkfs -t
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
cd /
ls
cd root
ls -la
cd /
ls
mkdir www_dir
ls
mkdir backup_dir
cd /etc
ls
find -name "index.php"
find . -name "index.php"
find .. -name "index.php"
cd ..
cd /var/www/html
ls
mv index.php /www_dir
mv logo.png /www_dir
ls
cd ..
ls
cd /
ls
cd www_dir/
ls
cd ..
ls
cd /etc
ls
ls -color:auto
ls --color:auto
ls --help
ls --color=auto
alias ls "ls --color=auto"
alias ls='ls --color=auto'
ls
cd ..
df
df -h
lsblk
mount /dev/sdc/sdc1 /www_dir/
ls /www_dir/
ls
nano /etc/fstab 
lsblk

mount /dev/sdc/sdc1 /www_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir/
lsblk
nano /etc/fstab 
lsblk
umount /dev/sdc1
umount /dev/sdc2
lsblk
poweroff
lsblk
cd /
ls
cd /opt/
ls
ls -la
ls -l
ls -a
touch particion.txt
ls
cd ..
ls /proc/
nano /proc/partitions 
cat /proc/partitions > /opt/particion.txt 
ls
cd /etc
ls
cd apache2/
ls
ls
ls -la
nano apache2.conf 
nano apache2.conf 
ls
cd sites-available/
ls
nano 000-default.conf 
nano apache2.conf 
cd ..
nano apache2.conf 
cd ..
apache2ctl configtest
systemctl restart apache2
systemctl status apache2
clear
hostname
hostname -I
nano /apache2/apache2.conf 
cd apache2/
nano apache2.conf 
cd /
ls
sudo apt install mariadb-server
systemctl status mariadb
:wq
clear
ls
cd root
ls
cd ~
ls
ls -la
rm index.php 
rm logo.png 
ls -la
exit
ls
ls -la
mariadb --help
mariadb < /root/db.sql 
mariadb
mariadb
ls
ls -la
/
cd /
ls
cd www_dir/
ls -la
cd ~
ls
ls -la
lsblk
cd /www_dir/
ls
ls -la
cd root
cd ~
ls
cd /
ls
cd root
/ls
ls
ls -la
cd /etc/apache2/
nano apache2.conf 
fstab
cd ..
nano fstab 
cd ~
ls
cd /www_dir/
ls -la
cd /
find -i "index.php"
find -name "index.php"
exit
cd /
ls
ls www_dir/
cd /etc/apache2/sites-
cd /etc/apache2/sites-available/
ls
nano 000-default.conf 
cd ..
ls
nano apache2.conf 
systemctl restart apache2
tail /var/log/apache2/error.log 
apt install php-mysql
systemctl restart apache2
tail /var/log/apache2/error.log 
ls
sudo apt update
apt list --upgradable
php -m | grep mysqli
systemctl restart apache2
cd /
ls
cd www_dir/
ls
cd ..
cd /etc/apache2/
ls
nano apache2.conf 
cd ..
cd apache2/
ls
cd sites-available/
ls
apache2ctl configtest
ls

mariadb
systemctl restart apache2
mariadb
poweroff
cd /etc
ls
cd cron.weekly/
ls
nano 0anacron 
nano man-db 
cd /
ls
cd opt/
ls
mkdir scripts
ls
exit
